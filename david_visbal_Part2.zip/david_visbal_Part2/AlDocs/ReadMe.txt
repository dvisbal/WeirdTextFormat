------ Command Line ------

python WeirdTextFormat [encode|decode]
-- reads from stdin
-- writes to stdout

# encode from in_encode.txt, which contains "FRED"
python WeirdTextFormat.py encode < in_encode.txt

# decode from in_decode.txt, a list of 32bit ints seperated by line
python WeirdTextFormat.py decode < in_decode.txt


------ Import ------

from WeirdTextFormat import encode, decode
s = "FRED"
s == decode(encode(s))


----- Run Unit Tests -----

python TestWeirdTextFormat.py


