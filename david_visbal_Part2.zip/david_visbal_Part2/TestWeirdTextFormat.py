# Copyright (c) 2008 Art & Logic, Inc. All Rights Reserved.

# Test encode/decode functions in the WeirdTextFormat package
#
# usage: python TestWeirdTextFormat.py

import unittest

from WeirdTextFormat import chunk, encode, decode


class ATestWeirdTextFormat(unittest.TestCase):
   def test_chunk_FRED(self):
      self.assertCountEqual(chunk('FRED', 4), ['FRED'])

   def test_chunk_FREDFRED(self):
      self.assertCountEqual(chunk('FREDFRED', 4), ['FRED', 'FRED'])

   def test_chunk_FRE(self):
      self.assertCountEqual(chunk('FRE', 4), ['FRE\0'])

   def test_chunk_FREDE(self):
      self.assertCountEqual(chunk('FREDE', 4), ['FRED', 'E\0\0\0'])

   def test_A(self):
      self.assertCountEqual(encode('A'), [16777217])
   
   def test_FRED(self):
      self.assertCountEqual(encode('FRED'), [251792692])
   
   def test_special_chars(self):
      self.assertCountEqual(encode(' :^)'), [79094888])
   
   def test_foo(self):
      self.assertCountEqual(encode('foo'), [124807030])
        
   def test_spacefoo(self):
      self.assertCountEqual(encode(' foo'), [250662636])
   
   def test_foot(self):
      self.assertCountEqual(encode('foot'), [267939702])
        
   def test_BIRD(self):
      self.assertCountEqual(encode('BIRD'), [251930706])
    
   def test_dotdotdotdot(self):
      self.assertCountEqual(encode('....'), [15794160])
        
   def test_special_chars_2(self):
      self.assertCountEqual(encode('^^^^'), [252706800])
        
   def test_Woot(self):
      self.assertCountEqual(encode('Woot'), [266956663])
        
   def test_no(self):
      self.assertCountEqual(encode('no'), [53490482])
   
   def test_encode_tacocat(self):
      self.assertCountEqual(encode('tacocat'), [267487694, 125043731])

   def test_decode_tacocat(self):
      self.assertEqual(decode([267487694, 125043731]), 'tacocat')

   def test_encode_never_odd_or_even(self):
      self.assertCountEqual(encode('never odd or even'), 
       [267657050, 233917524, 234374596, 250875466, 17830160]
       )

   def test_decode_never_odd_or_even(self):
      self.assertEqual(
       decode([267657050, 233917524, 234374596, 250875466, 17830160]), 
       'never odd or even'
       )

   def test_encode_lager_sir_is_regal(self):
      self.assertCountEqual(encode('lager, sir, is regal'), 
       [267394382, 167322264, 66212897, 200937635, 267422503]
       )

   def test_decode_lager_sir_is_regal(self):
      self.assertEqual(
       decode([267394382, 167322264, 66212897, 200937635, 267422503]), 
       'lager, sir, is regal'
       )

   def test_encode_go_hang_a_salami_Im_a_lasagna_hog(self):
      self.assertCountEqual(encode('go hang a salami, I\'m a lasagna hog'), 
       [200319795, 133178981, 234094669, 267441422, 78666124, 99619077, 
       267653454, 133178165, 124794470]
       )

   def test_decode_go_hang_a_salami_Im_a_lasagna_hog(self):
      self.assertEqual(
       decode([200319795, 133178981, 234094669, 267441422, 78666124, 99619077,
       267653454, 133178165, 124794470]), 
       'go hang a salami, I\'m a lasagna hog'
       )

   def test_encode_egad_a_base_tone_denotes_a_bad_age(self):
      self.assertCountEqual(encode('egad, a base tone denotes a bad age'), 
       [267389735, 82841860, 267651166, 250793668, 233835785, 267665210, 
       99680277, 133170194, 124782119]
       )

   def test_decode_egad_a_base_tone_denotes_a_bad_age(self):
      self.assertEqual(
       decode([267389735, 82841860, 267651166, 250793668, 233835785, 
       267665210, 99680277, 133170194, 124782119]), 
       'egad, a base tone denotes a bad age'
       )

   def test_encode_decode_egad_a_base_tone_denotes_a_bad_age(self):
      self.assertEqual(
       'egad, a base tone denotes a bad age',
       decode(encode('egad, a base tone denotes a bad age'))
       )

   

if __name__ == '__main__':
   unittest.main()
